#include "Id_card.h"

void Id_card::vts()
{
  Serial_util serial_util;
  Serial.write(major_relase_id);
  serial_util.int16(update_id);
  Serial.write(version_id);
}

