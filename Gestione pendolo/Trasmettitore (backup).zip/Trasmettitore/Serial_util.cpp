#include "Serial_util.h"

void Serial_util::int16(int input){
  unsigned char buf[2];
  memcpy(buf,&input,sizeof(int));
  Serial.write(buf,2);
}

