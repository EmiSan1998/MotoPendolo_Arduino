#include "Lista.h"



Lista::Lista()
{
	testa = NULL;
	coda = NULL;
}

void Lista::init(){
  testa = NULL;
  coda = NULL;
}

void Lista::push(unsigned int tempo)
{
	Elemento* temp = new Elemento;
	temp->SetTempo(tempo);
	temp->setSuccessivo(NULL);
	if (testa == NULL) {
		testa = temp;
		coda = temp;
	}
	else {
		coda->setSuccessivo(temp);
		coda = temp;
	}
}

bool Lista::pop()
{
	//if (testa == NULL) {
  //  Serial.println("false");
	//	return false;
	//}
	//else 
	if (testa == coda) {
		testa->printTempo();
		delete testa;
		testa = NULL;
		coda = NULL;
    return true;
	}
	else {
		testa->printTempo();
		Elemento* temp = testa;
		testa = testa->get_successivo();
    delete temp;
    return true;
	}
}

bool Lista::isEmpty(){
  if(testa==NULL){
    return true;
  }
  else{
    return false;
  }
}

