#pragma once

#include<arduino.h>

#include "Serial_util.h"

class Elemento
{
public:
	void SetTempo(unsigned int);
	void printTempo();
	void setSuccessivo(Elemento*);
	Elemento* get_successivo();

private:
	unsigned int tempo;
	Elemento* successivo;
};

