#pragma once

#include<arduino.h>

#include "Serial_util.h"  

class Id_card
{
public:
  void vts();

private:
  static const byte major_relase_id = 0;
  static const unsigned int update_id = 3;
  static const char version_id = 'T';
};

