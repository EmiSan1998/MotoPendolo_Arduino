#include "Elemento.h"

void Elemento::SetTempo(unsigned int tempo)
{
	this->tempo = tempo;
}

void Elemento::printTempo()
{
  Serial_util serial_util;
	serial_util.int16(this->tempo);
}

void Elemento::setSuccessivo(Elemento *successivo)
{
	this->successivo = successivo;
}

Elemento * Elemento::get_successivo()
{
	return this->successivo;
}
