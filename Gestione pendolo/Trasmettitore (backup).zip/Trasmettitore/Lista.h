#pragma once

#include <Arduino.h>
#include "Elemento.h"  

class Lista
{
public:
	Lista();
  void init();
	void push(unsigned int);
	bool pop();
  bool isEmpty(); 

private:
	Elemento *testa;
	Elemento *coda;
};

