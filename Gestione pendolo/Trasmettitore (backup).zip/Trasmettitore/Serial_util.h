#pragma once

#include<Arduino.h>

class Serial_util
{
public:
  void int16(int);
};

